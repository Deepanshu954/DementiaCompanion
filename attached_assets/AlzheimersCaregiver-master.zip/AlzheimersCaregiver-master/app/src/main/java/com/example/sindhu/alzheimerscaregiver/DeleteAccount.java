package com.example.sindhu.alzheimerscaregiver;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;


public class DeleteAccount extends AppCompatActivity {


}
