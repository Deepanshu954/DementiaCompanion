// final String baseURL = 'http://10.10.11.56:8000';
final String baseURL = 'https://api.anuj-paudel.com.np';
final String wsURL = 'ws://api.anuj-paudel.com.np/ws/socket-server/';
final String wsAudioURL = 'ws://api.anuj-paudel.com.np/ws/audio/';
